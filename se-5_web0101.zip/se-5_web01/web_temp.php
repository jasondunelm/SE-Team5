<!DOCTYPE html>
<?php

session_start();
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Homepage</title>

    <?php
    include('meta_data.php');
    ?>

</head>
<body>

<?php
include('header.php');
?>


<?php
include('footer.php');
?>
</body>
</html>

