
<div class="footer">

   <nav class="navbar navbar-expand-sm bg-light" id="footer">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="https://www.dur.ac.uk/contactform2/?pageid=59579">Comments & Questions</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://www.dur.ac.uk/about/terms/">Disclaimer</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://www.dur.ac.uk/about/trading_name/">Trading Name</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://www.dur.ac.uk/about/cookies/">Cookies usage policy</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://www.dur.ac.uk/ig/dp/privacy/">Privacy Notices</a>
            </li>
        </ul>
  </nav>
</div>




