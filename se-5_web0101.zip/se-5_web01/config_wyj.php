<?php
$db_host = 'mysql:host=127.0.0.1';
$db_name = 'dbname=test';
$db_user = 'root';
$db_pass = 'mon97day';
?>