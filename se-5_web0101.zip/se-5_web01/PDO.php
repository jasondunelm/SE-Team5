<?php
/**
 * Created by PhpStorm.
 * User: 典哥威武
 * Date: 2019/3/21
 * Time: 23:29
 */
?>

<?php
//$pdo = new PDO('mysql:host=mysql.dur.ac.uk;dbname=Xmkxx27_summative_assignment','mkxx27', 'fe35ast');
$pdo = new PDO('mysql:host=localhost:3306/sakila;dbname=tcmsystem','root', '0617');
?>
